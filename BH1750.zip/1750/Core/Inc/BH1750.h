#ifndef __BH1750_H
#define __BH1750_H

//#include "stm32f4xx_hal_msp.h"

#define BH1750Address 0x23

void BH1750_Init();
BH1750_Read(void);
//--------------------------------------------------------------
#endif // __BH1750_H
