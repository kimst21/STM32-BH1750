/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "BH1750.h"   // BH1750 조도 센서 라이브러리
#include "fonts.h"    // 폰트 관련 라이브러리
#include "ssd1306.h"  // SSD1306 OLED 디스플레이 라이브러리
#include <stdio.h>    // sprintf() 함수 사용을 위한 라이브러리
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
char strCopy[15];  // OLED에 출력할 문자열 저장 변수
uint16_t LUX = 0;  // BH1750 센서에서 읽은 조도 값 저장 변수
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);  // 시스템 클럭 설정 함수

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* MCU 초기화 ---------------------------------------------------------------*/
  HAL_Init();  // HAL 라이브러리 초기화
  SystemClock_Config();  // 시스템 클럭 설정

  /* 주변 장치 초기화 ---------------------------------------------------------*/
  MX_GPIO_Init();  // GPIO 초기화
  MX_I2C3_Init();  // I2C3 초기화

  /* 센서 및 디스플레이 초기화 ------------------------------------------------*/
  BH1750_Init();    // BH1750 조도 센서 초기화
  SSD1306_Init();   // SSD1306 OLED 초기화

  /* 메인 루프 ----------------------------------------------------------------*/
  while (1)
  {
      LUX = BH1750_Read();  // BH1750 조도 센서에서 LUX 값 읽기

      SSD1306_Fill(SSD1306_COLOR_BLACK); // 배경을 검은색으로 덮기
      SSD1306_GotoXY(0, 0);  // OLED 디스플레이의 (0,0) 위치로 이동
      sprintf(strCopy, "LUX=%d", LUX);  // 측정된 LUX 값을 문자열로 변환
      SSD1306_Puts(strCopy, &Font_11x18, 1);  // 변환된 문자열을 OLED에 출력
      SSD1306_UpdateScreen();  // OLED 화면 업데이트

      HAL_Delay(1000);  // 1초(1000ms) 대기 후 다시 측정
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
