#include "BH1750.h"
#include "stm32f4xx_hal.h"
I2C_HandleTypeDef hi2c3;

void BH1750_Init()
{
	uint8_t Cmd = 0x10;

	HAL_I2C_Master_Transmit(&hi2c3, BH1750Address << 1, &Cmd, 1, 500);
}
//------------------------------------------------------------------------------

int BH1750_Read()
{

	uint8_t buff[3];
	uint16_t val = 0;
	HAL_I2C_Master_Receive(&hi2c3, (BH1750Address << 1) | 0x01, buff, 2, 500);
	val = (uint16_t)(((buff[0] << 8) | buff[1]) / 1.2);

	return val;
}
