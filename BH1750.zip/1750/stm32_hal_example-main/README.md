# STM32Cube_Example_Project

## stm32f411ceux_swo
- Use printf function through SWO pin of ST-LINK
- https://mokhwasomssi.tistory.com/203

## nucleo-f103rb
- NUCLEO-F103RB로 STM32CubeIDE 시작하기
- 클럭세팅, 내장 LED 제어, UART 송수신
- https://mokhwasomssi.tistory.com/211?category=927528